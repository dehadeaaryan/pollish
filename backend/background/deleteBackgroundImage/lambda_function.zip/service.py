from repository import delete_background_files

def delete_background_service(pollish_id: str):
    return delete_background_files(pollish_id)
