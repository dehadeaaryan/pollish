from repository import get_background_image

def get_background_service(pollish_id: str):
    return get_background_image(pollish_id)
